//
//  ViewController.h
//  广告滚动视图网络版
//
//  Created by QzydeMac on 15/4/26.
//  Copyright (c) 2015年 Qzy. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Demo1Controller : UIViewController


@end

