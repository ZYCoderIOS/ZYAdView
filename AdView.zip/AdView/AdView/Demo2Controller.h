//
//  ViewControllerLocalImageDemo.h
//  AdView
//
//  Created by QzydeMac on 15/5/28.
//  Copyright (c) 2015年 Qzy. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Demo2Controller : UIViewController

@end
